"""
CHI Insurance Brokers — PPTX Slide Builder

Improvements over v1:
  • Separated into focused slide-builder functions (cover, overview, proposal, table, closing)
  • Monthly premium shown on overview cards and per-proposal slides
  • Coverage score badge (0–10) on each card and proposal slide
  • Per-row unique-coverage marker (★) in comparison table
  • 14-row comparison table with new fields (chronic, evacuation, dental, psychiatric, organ)
  • key_notes displayed on closing slide under recommended plan
  • Logo support on cover slide
  • Fixed outpatient_pct null guard
  • Fixed n_props title for 2-plan comparisons
"""

import io
from datetime import datetime

from pptx import Presentation
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

from config import C, insurer_color, rgb
from extraction import compute_score


# ─── LOW-LEVEL DRAWING HELPERS ──────────────────────────────────────

def add_rect(slide, x, y, w, h, fill_color, line_color=None, line_width=None):
    """Add a filled rectangle at (x, y) inches with size (w, h) inches."""
    shape = slide.shapes.add_shape(1, Inches(x), Inches(y), Inches(w), Inches(h))
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    if line_color:
        shape.line.color.rgb  = line_color
        shape.line.width      = Pt(line_width or 1)
    else:
        shape.line.fill.background()
    return shape


def add_text(slide, text, x, y, w, h, size=12, bold=False, italic=False,
             color=None, align=PP_ALIGN.LEFT, valign="middle", wrap=True):
    """Add a text box at (x, y) inches."""
    txBox = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf    = txBox.text_frame
    tf.word_wrap = wrap

    if valign == "middle":
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    elif valign == "bottom":
        tf.vertical_anchor = MSO_ANCHOR.BOTTOM

    p          = tf.paragraphs[0]
    p.alignment = align
    run        = p.add_run()
    run.text   = str(text)
    run.font.size   = Pt(size)
    run.font.bold   = bold
    run.font.italic = italic
    if color:
        run.font.color.rgb = color
    return txBox


# ─── SHARED SLIDE UTILITIES ─────────────────────────────────────────

def _footer(slide, text, light=False):
    add_rect(slide, 0, 7.18, 13.33, 0.32, C["navy"] if light else C["navyDark"])
    add_text(slide, text, 0.3, 7.18, 12.7, 0.32,
             size=8, color=C["teal"], align=PP_ALIGN.CENTER)


def _top_bar(slide, color):
    add_rect(slide, 0, 0, 13.33, 0.1, color)


def _add_logo(slide, logo_bytes, x, y, h_in):
    """Safely place a logo image; silently skip if bytes are invalid."""
    if not logo_bytes:
        return
    try:
        slide.shapes.add_picture(
            io.BytesIO(logo_bytes), Inches(x), Inches(y), height=Inches(h_in)
        )
    except Exception:
        pass


def _sym(prop: dict) -> str:
    cur = prop.get("currency") or "EUR"
    return "€" if cur == "EUR" else ("$" if cur == "USD" else "£")


def _monthly(prop: dict):
    """Return monthly equivalent of annual_premium, or None."""
    try:
        annual = int(str(prop.get("annual_premium", 0) or 0).replace(",", ""))
        return round(annual / 12) if annual else None
    except (ValueError, TypeError):
        return None


def _is_covered(val) -> bool:
    if val is None:
        return False
    s = str(val).strip()
    return s not in ("", "null", "None", "—") and "Not Covered" not in s


def _display(val) -> str:
    return str(val) if _is_covered(val) else "ΔΕΝ καλύπτει"


def _n_props_label(n: int) -> str:
    return {2: "Δύο", 3: "Τρεις", 4: "Τέσσερις"}.get(n, str(n))


def _fmt_outpatient(prop: dict, sym: str) -> str:
    """Format outpatient coverage string, guarding against null % value."""
    ol  = prop.get("outpatient_limit")
    pct = prop.get("outpatient_pct")
    if not ol or str(ol).strip() in ("null", "None", "", "Not Covered"):
        return ol or "Not Covered"
    pct_str = (
        f" ({pct}%)"
        if pct and str(pct).strip() not in ("null", "None", "")
        else ""
    )
    return f"εως {sym}{ol}{pct_str}"


# ─── SLIDE 1: COVER ─────────────────────────────────────────────────

def _build_cover(prs, layout, client_name, client_members, proposals,
                 footer_text, logo_bytes):
    s = prs.slides.add_slide(layout)
    s.background.fill.solid()
    s.background.fill.fore_color.rgb = C["navyDark"]

    _top_bar(s, C["teal"])
    add_rect(s, 0, 0.1, 5.0, 7.08, C["navy"])
    add_rect(s, 5.0, 0.1, 0.05, 7.08, C["teal"])

    # Optional logo on left panel
    if logo_bytes:
        _add_logo(s, logo_bytes, 0.5, 0.9, 1.1)

    logo_offset = 1.25 if logo_bytes else 0.0
    add_text(s, "ΑΣΦΑΛΙΣΗ ΥΓΕΙΑΣ", 0.3, 2.6 + logo_offset * 0.3, 4.4, 0.5,
             size=12, bold=True, color=C["teal"], align=PP_ALIGN.CENTER)
    add_text(s, "ΣΥΓΚΡΙΤΙΚΗ ΑΝΑΛΥΣΗ", 0.3, 3.1 + logo_offset * 0.3, 4.4, 0.4,
             size=10, color=rgb(0x9D, 0xC4, 0xD8), align=PP_ALIGN.CENTER)

    # Right panel — client details
    add_text(s, "Πρόταση", 5.5, 1.0, 7.5, 0.8,
             size=22, italic=True, color=C["teal"])
    add_text(s, "Ασφάλισης Υγείας", 5.5, 1.7, 7.5, 1.2,
             size=44, bold=True, color=C["white"])
    add_rect(s, 5.5, 3.0, 7.6, 0.05, C["teal"])

    add_text(s, client_name, 5.5, 3.15, 7.5, 0.6,
             size=20, bold=True, color=C["white"])
    member_str = "  ·  ".join(
        f"{m.get('role', '')} ({m.get('age', '')} ετών)" for m in client_members
    )
    add_text(s, member_str, 5.5, 3.75, 7.5, 0.45,
             size=12, color=rgb(0x9D, 0xC4, 0xD8))

    # Date badge
    add_rect(s, 5.5, 4.4, 2.1, 0.45, C["teal"])
    add_text(s, datetime.now().strftime("%B %Y"), 5.5, 4.4, 2.1, 0.45,
             size=11, bold=True, color=C["navy"], align=PP_ALIGN.CENTER)

    # Insurer name chips along bottom
    for i, prop in enumerate(proposals[:4]):
        xp  = 5.5 + i * 1.95
        col = insurer_color(prop.get("insurer", ""))
        add_rect(s, xp, 5.2, 1.82, 0.42, col)
        add_text(s, prop.get("insurer", "").upper(), xp, 5.2, 1.82, 0.42,
                 size=8, bold=True, color=C["white"], align=PP_ALIGN.CENTER)

    _footer(s, footer_text, light=True)


# ─── SLIDE 2: OVERVIEW CARDS ────────────────────────────────────────

def _build_overview(prs, layout, client_name, proposals, recommended_idx, footer_text):
    s = prs.slides.add_slide(layout)
    s.background.fill.solid()
    s.background.fill.fore_color.rgb = C["navy"]
    _top_bar(s, C["gold"])

    n = len(proposals)
    add_text(s, f"{_n_props_label(n)} Προτάσεις για {client_name}",
             0.4, 0.18, 12.5, 0.62, size=28, bold=True, color=C["white"])
    add_text(s, "Από την οικονομική επιλογή έως την ολοκληρωμένη διεθνή κάλυψη",
             0.4, 0.82, 12.5, 0.38, size=12, italic=True,
             color=rgb(0x9D, 0xC4, 0xD8))

    card_w = (13.33 - 0.8 - (n - 1) * 0.25) / n

    for i, prop in enumerate(proposals):
        xp     = 0.4 + i * (card_w + 0.25)
        is_rec = (i == recommended_idx)
        col    = insurer_color(prop.get("insurer", ""))
        bg_col = rgb(0x1A, 0x2F, 0x45) if is_rec else rgb(0x17, 0x35, 0x4E)
        border = C["gold"] if is_rec else col
        score  = compute_score(prop)
        sym    = _sym(prop)
        monthly = _monthly(prop)

        # Card body
        add_rect(s, xp, 1.38, card_w, 5.62, bg_col,
                 line_color=border, line_width=2.0 if is_rec else 0.8)
        # Header bar (insurer color)
        add_rect(s, xp, 1.38, card_w, 0.5, col)

        label = "★ ΠΡΟΤΕΙΝΟΜΕΝΗ" if is_rec else f"ΕΠΙΛΟΓΗ {chr(65 + i)}"
        add_text(s, label, xp, 1.38, card_w, 0.5,
                 size=9, bold=True,
                 color=C["navy"] if is_rec else C["white"],
                 align=PP_ALIGN.CENTER)

        add_text(s, prop.get("insurer", ""), xp + 0.1, 1.93, card_w - 0.2, 0.38,
                 size=10, bold=True, color=col, align=PP_ALIGN.CENTER)
        add_text(s, prop.get("plan_name", ""), xp + 0.1, 2.31, card_w - 0.2, 0.58,
                 size=10, bold=True, color=C["white"], align=PP_ALIGN.CENTER)

        # Annual premium
        price_bg = C["gold"] if is_rec else rgb(0x2A, 0x4A, 0x63)
        price_fg = C["navy"] if is_rec else C["teal"]
        add_rect(s, xp + card_w * 0.1, 2.98, card_w * 0.8, 0.56, price_bg)
        premium  = prop.get("annual_premium", "")
        add_text(s, f"{sym}{premium}" if premium else "—",
                 xp + card_w * 0.1, 2.98, card_w * 0.8, 0.56,
                 size=20, bold=True, color=price_fg, align=PP_ALIGN.CENTER)

        # Monthly equivalent
        if monthly:
            add_text(s, f"{sym}{monthly} / μήνα",
                     xp + 0.1, 3.57, card_w - 0.2, 0.28,
                     size=8, italic=True,
                     color=rgb(0x9D, 0xC4, 0xD8), align=PP_ALIGN.CENTER)

        # Score badge
        sc_col = C["green"] if score >= 7 else (C["orange"] if score >= 5 else C["red"])
        add_rect(s, xp + card_w * 0.2, 3.9, card_w * 0.6, 0.28, sc_col)
        add_text(s, f"Score: {score} / 10",
                 xp + card_w * 0.2, 3.9, card_w * 0.6, 0.28,
                 size=8, bold=True, color=C["white"], align=PP_ALIGN.CENTER)

        # Geography
        add_text(s, prop.get("geography", ""),
                 xp + 0.1, 4.22, card_w - 0.2, 0.3,
                 size=8, italic=True,
                 color=rgb(0x9D, 0xC4, 0xD8), align=PP_ALIGN.CENTER)

        # Key summary bullets
        bullets = [
            f"Απαλλαγή: {prop.get('deductible') or '—'}",
            f"Νοσηλεία: {prop.get('inpatient') or '—'}",
            f"MRI/PET:  {prop.get('mri_ct_pet') or '—'}",
            f"Αναμονή:  {prop.get('waiting_period') or '—'}",
        ]
        for bi, b in enumerate(bullets):
            add_text(s, f"• {b}", xp + 0.15, 4.56 + bi * 0.44, card_w - 0.3, 0.4,
                     size=8, color=rgb(0xC8, 0xDF, 0xF0))

    _footer(s, footer_text, light=True)


# ─── SLIDES 3+: ONE PER PROPOSAL ────────────────────────────────────

def _build_proposal_slide(prs, layout, prop, idx, is_rec, footer_text):
    s = prs.slides.add_slide(layout)
    s.background.fill.solid()
    s.background.fill.fore_color.rgb = C["navyDark"] if is_rec else C["offWhite"]

    col = insurer_color(prop.get("insurer", ""))
    _top_bar(s, C["gold"] if is_rec else col)
    add_rect(s, 0, 0.1, 0.35, 7.08, C["gold"] if is_rec else col)

    label = (
        f"★ ΕΠΙΛΟΓΗ {chr(65 + idx)} — ΠΡΟΤΕΙΝΟΜΕΝΗ"
        if is_rec else f"ΕΠΙΛΟΓΗ {chr(65 + idx)}"
    )
    add_text(s, label, 0.5, 0.15, 8.0, 0.42,
             size=10, bold=True, color=C["gold"] if is_rec else col)
    add_text(s, f"{prop.get('insurer', '')} — {prop.get('plan_name', '')}",
             0.5, 0.55, 9.5, 0.7, size=23, bold=True,
             color=C["white"] if is_rec else C["navy"])

    # Price box (top-right)
    sym     = _sym(prop)
    monthly = _monthly(prop)
    price_col = C["gold"] if is_rec else col
    add_rect(s, 10.15, 0.25, 2.85, 1.1, price_col)
    add_text(s, f"{sym}{prop.get('annual_premium', '—')}",
             10.15, 0.25, 2.85, 0.68,
             size=25, bold=True,
             color=C["navy"] if is_rec else C["white"],
             align=PP_ALIGN.CENTER)
    add_text(s, "ετήσιο ασφάλιστρο",
             10.15, 0.91, 2.85, 0.28, size=8,
             color=rgb(0xC8, 0xDF, 0xF0) if is_rec else rgb(0x5A, 0x4A, 0x00),
             align=PP_ALIGN.CENTER)

    # Monthly note
    if monthly:
        add_text(s, f"≈ {sym}{monthly} / μήνα",
                 10.15, 1.37, 2.85, 0.26, size=8, italic=True,
                 color=rgb(0xC8, 0xDF, 0xF0) if is_rec else rgb(0x5A, 0x4A, 0x00),
                 align=PP_ALIGN.CENTER)

    # Score badge
    score  = compute_score(prop)
    sc_col = C["green"] if score >= 7 else (C["orange"] if score >= 5 else C["red"])
    add_rect(s, 10.55, 1.68, 2.1, 0.32, sc_col)
    add_text(s, f"Score: {score} / 10",
             10.55, 1.68, 2.1, 0.32,
             size=8, bold=True, color=C["white"], align=PP_ALIGN.CENTER)

    # Key parameters (top-left grid)
    params = [
        ("Μέγιστο Κεφάλαιο", f"{sym}{prop.get('max_coverage') or '—'}"),
        ("Απαλλαγή",          prop.get("deductible") or "—"),
        ("Γεωγραφία",         prop.get("geography") or "—"),
        ("Θέση Νοσηλείας",    prop.get("hospital_class") or "—"),
    ]
    for pi, (k, v) in enumerate(params):
        yp = 1.55 + pi * 0.5
        lbl_bg = C["navy"] if not is_rec else rgb(0x1A, 0x35, 0x50)
        lbl_fg = C["white"] if not is_rec else C["gold"]
        add_rect(s, 0.5, yp, 3.1, 0.42, lbl_bg)
        add_text(s, k, 0.5, yp, 3.1, 0.42,
                 size=9, bold=True, color=lbl_fg, align=PP_ALIGN.CENTER)
        add_text(s, v, 3.7, yp + 0.04, 6.2, 0.42,
                 size=9,
                 color=C["textDark"] if not is_rec else rgb(0xC8, 0xDF, 0xF0))

    # ── LEFT PANEL: Coverages ──
    add_rect(s, 0.5, 3.63, 6.0, 0.36, C["green"])
    add_text(s, "✓  ΚΑΛΥΨΕΙΣ", 0.5, 3.63, 6.0, 0.36,
             size=9, bold=True, color=C["white"], align=PP_ALIGN.CENTER)

    covers = [
        ("Νοσηλεία",           prop.get("inpatient") or "—"),
        ("Εξωνοσοκ.",          _fmt_outpatient(prop, sym)),
        ("MRI / CT / PET",     prop.get("mri_ct_pet") or "—"),
        ("Καρκίνος",            prop.get("cancer") or "—"),
        ("Χρόνιες Παθήσεις",   prop.get("chronic_conditions") or "—"),
        ("Εκκένωση/Μεταφορά",  prop.get("evacuation_repatriation") or "—"),
        ("Φυσιοθεραπεία",       prop.get("physiotherapy") or "—"),
    ]
    for ci, (k, v) in enumerate(covers):
        yp   = 4.03 + ci * 0.41
        tick = "✓" if _is_covered(v) else "✗"
        tc   = C["green"] if tick == "✓" else C["red"]
        add_text(s, tick, 0.55, yp, 0.4, 0.37,
                 size=11, bold=True, color=tc, align=PP_ALIGN.CENTER)
        add_text(s, k, 1.0, yp, 1.85, 0.37,
                 size=9, bold=True,
                 color=C["white"] if is_rec else C["navy"])
        add_text(s, v, 2.9, yp, 3.5, 0.37,
                 size=8,
                 color=rgb(0xC8, 0xDF, 0xF0) if is_rec else C["textDark"])

    # ── RIGHT PANEL: Notes ──
    add_rect(s, 6.8, 3.63, 6.2, 0.36, C["orange"])
    add_text(s, "⚠  ΣΗΜΑΝΤΙΚΕΣ ΠΑΡΑΤΗΡΗΣΕΙΣ", 6.8, 3.63, 6.2, 0.36,
             size=9, bold=True, color=C["white"], align=PP_ALIGN.CENTER)

    extra_notes = [
        f"Ψυχ. Νοσηλεία: {prop.get('psychiatric_inpatient') or 'N/A'}",
        f"Οδοντιατρική Έκτ.: {prop.get('dental_emergency') or 'N/A'}",
        f"Αναμονή: {prop.get('waiting_period') or 'Άμεση'}",
        f"Προϋπ. παθήσεις: {prop.get('preexisting') or '—'}",
    ]
    all_notes = list(prop.get("key_notes") or []) + extra_notes

    for ni, note in enumerate(all_notes[:7]):
        yp = 4.03 + ni * 0.41
        add_text(s, f"• {note}", 6.85, yp, 6.1, 0.38,
                 size=8.5,
                 color=rgb(0xC8, 0xDF, 0xF0) if is_rec else C["textDark"])

    _footer(s, footer_text, light=is_rec)


# ─── COMPARISON TABLE ───────────────────────────────────────────────

def _build_comparison_table(prs, layout, proposals, recommended_idx, footer_text):
    s = prs.slides.add_slide(layout)
    s.background.fill.solid()
    s.background.fill.fore_color.rgb = C["offWhite"]
    _top_bar(s, C["teal"])

    add_text(s, "Σύγκριση Καλύψεων — Πίνακας",
             0.4, 0.12, 12.5, 0.55, size=23, bold=True, color=C["navy"])
    add_text(s, "★ = Μοναδική κάλυψη σε αυτό το πλάνο  |  Έντονο = Προτεινόμενη επιλογή",
             0.4, 0.67, 12.5, 0.28, size=8, italic=True, color=C["orange"])

    n = len(proposals)
    label_w  = 3.2
    data_w   = (13.33 - 0.8 - label_w) / n
    col_widths = [label_w] + [data_w] * n
    xstarts    = [0.4]
    for cw in col_widths[:-1]:
        xstarts.append(xstarts[-1] + cw)

    # Column headers
    header_colors      = [C["navy"]] + [insurer_color(p.get("insurer", "")) for p in proposals]
    header_text_colors = [C["white"]] * len(col_widths)
    if recommended_idx < n:
        header_colors[recommended_idx + 1]      = C["gold"]
        header_text_colors[recommended_idx + 1] = C["navy"]

    headers = ["ΚΑΛΥΨΗ"] + [
        f"{p.get('insurer','')}\n{p.get('plan_name','')}" for p in proposals
    ]
    for h, xp, cw, hc, htc in zip(
        headers, xstarts, col_widths, header_colors, header_text_colors
    ):
        add_rect(s, xp, 1.0, cw, 0.58, hc)
        add_text(s, h, xp + 0.05, 1.0, cw - 0.1, 0.58,
                 size=7.5, bold=True, color=htc, align=PP_ALIGN.CENTER)

    # Data rows — 14 rows, 0.37 height each → fits on slide
    row_h   = 0.37
    start_y = 1.62

    row_data = [
        ("Max Κεφάλαιο / Έτος",   lambda p: f"{_sym(p)}{p.get('max_coverage','—') or '—'}"),
        ("Απαλλαγή",               lambda p: p.get("deductible", "—") or "—"),
        ("Γεωγραφία",              lambda p: p.get("geography", "—") or "—"),
        ("Θέση Νοσηλείας",         lambda p: p.get("hospital_class", "—") or "—"),
        ("Νοσηλεία In-Patient",    lambda p: p.get("inpatient", "—") or "—"),
        ("Χρόνιες Παθήσεις",       lambda p: p.get("chronic_conditions", "—") or "—"),
        ("MRI / CT / PET",         lambda p: p.get("mri_ct_pet", "—") or "—"),
        ("Εξωνοσ. Καλύψεις",      lambda p: _fmt_outpatient(p, _sym(p))),
        ("Φυσιοθεραπεία",          lambda p: p.get("physiotherapy", "—") or "—"),
        ("Καρκίνος",                lambda p: p.get("cancer", "—") or "—"),
        ("Ψυχ. Νοσηλεία",          lambda p: p.get("psychiatric_inpatient", "—") or "—"),
        ("Οδοντιατρική Έκτ.",      lambda p: p.get("dental_emergency", "—") or "—"),
        ("Εκκένωση / Μεταφορά",   lambda p: p.get("evacuation_repatriation", "—") or "—"),
        ("Ετήσιο Ασφάλιστρο",     lambda p: f"{_sym(p)}{p.get('annual_premium','—') or '—'}"),
    ]

    for ri, (label, fn) in enumerate(row_data):
        yp = start_y + ri * row_h

        # Alternating row backgrounds
        row_bg = rgb(0xF4, 0xF9, 0xFF) if ri % 2 == 0 else C["white"]

        # Compute values and detect unique coverage per proposal
        vals          = [fn(p) for p in proposals]
        covered_flags = [_is_covered(v) for v in vals]
        n_covered     = sum(covered_flags)
        unique        = [covered_flags[pi] and n_covered == 1 for pi in range(n)]

        for ci, (xp, cw) in enumerate(zip(xstarts, col_widths)):
            is_rec_col = (ci == recommended_idx + 1)
            bg = (
                (rgb(0xFF, 0xF8, 0xE1) if ri % 2 == 0 else rgb(0xFF, 0xF3, 0xC4))
                if is_rec_col else row_bg
            )
            add_rect(s, xp, yp, cw, row_h, bg)

            if ci == 0:
                # Row label
                add_text(s, label, xp + 0.1, yp, cw - 0.12, row_h,
                         size=8.5, bold=True, color=C["navy"])
            else:
                pi      = ci - 1
                val     = vals[pi]
                display = _display(val)
                is_good = _is_covered(val)

                # Unique-coverage teal accent bar on the left edge
                if unique[pi]:
                    add_rect(s, xp, yp, 0.05, row_h, C["teal"])
                    display = f"★ {display}"

                # Text color
                if any(c in display for c in ("€", "$", "£")):
                    text_color = C["navy"]
                elif is_good:
                    text_color = C["green"]
                else:
                    text_color = C["red"]

                add_text(s, display, xp + 0.06, yp, cw - 0.1, row_h,
                         size=7.5, bold=is_rec_col,
                         color=text_color, align=PP_ALIGN.CENTER)

    _footer(s, footer_text)


# ─── CLOSING SLIDE ──────────────────────────────────────────────────

def _build_closing(prs, layout, proposals, recommended_idx, footer_text):
    s = prs.slides.add_slide(layout)
    s.background.fill.solid()
    s.background.fill.fore_color.rgb = C["navyDark"]
    _top_bar(s, C["gold"])

    add_text(s, "Η Πρότασή μας", 0.5, 0.2, 12.0, 0.65,
             size=30, bold=True, color=C["gold"])

    steps_y = 2.0   # default y-position for the 3 steps

    if recommended_idx < len(proposals):
        rec     = proposals[recommended_idx]
        sym     = _sym(rec)
        monthly = _monthly(rec)
        monthly_str = f"  ·  {sym}{monthly} / μήνα" if monthly else ""
        rec_text = (
            f"{rec.get('insurer', '')} — {rec.get('plan_name', '')}  "
            f"|  {sym}{rec.get('annual_premium', '')} / έτος{monthly_str}"
        )
        add_text(s, rec_text, 0.5, 0.92, 12.5, 0.55,
                 size=15, bold=True, color=C["white"])

        # Key advantages from recommended plan's key_notes
        key_notes = [n for n in (rec.get("key_notes") or []) if n]
        if key_notes:
            add_rect(s, 0.5, 1.58, 12.33, 0.32, rgb(0x1A, 0x35, 0x50))
            add_rect(s, 0.5, 1.58, 0.06, 0.32, C["gold"])
            add_text(s, "🔑  ΚΥΡΙΑ ΠΛΕΟΝΕΚΤΗΜΑΤΑ", 0.6, 1.58, 12.0, 0.32,
                     size=9, bold=True, color=C["gold"])

            for ni, note in enumerate(key_notes[:3]):
                add_text(s, f"✓  {note}", 0.65, 1.95 + ni * 0.37, 12.0, 0.34,
                         size=10, color=rgb(0xC8, 0xDF, 0xF0))

            steps_y = 3.15   # push steps down to make room for notes

    # Next steps
    steps = [
        ("ΒΗΜΑ 1", "Εντός 48ωρών",  "Έγκριση πρότασης & αποστολή ιατρικού ιστορικού"),
        ("ΒΗΜΑ 2", "Underwriting",   "Υπογραφή αίτησης — σαφής γνώση τι καλύπτεται"),
        ("ΒΗΜΑ 3", "Ενεργοποίηση",  "Άμεση κάλυψη χωρίς αναμονές"),
    ]
    for si, (tag, title, body) in enumerate(steps):
        xp = 0.5 + si * 4.25
        add_rect(s, xp, steps_y, 4.0, 2.5, rgb(0x1A, 0x35, 0x50))
        add_rect(s, xp, steps_y, 4.0, 0.56, C["gold"])
        add_text(s, tag, xp, steps_y, 4.0, 0.56,
                 size=12, bold=True, color=C["navy"], align=PP_ALIGN.CENTER)
        add_text(s, title, xp + 0.1, steps_y + 0.62, 3.8, 0.5,
                 size=13, bold=True, color=C["teal"], align=PP_ALIGN.CENTER)
        add_text(s, body, xp + 0.15, steps_y + 1.18, 3.7, 1.2,
                 size=10, color=rgb(0xC8, 0xDF, 0xF0), align=PP_ALIGN.CENTER)

    # Inspirational quote
    quote_y = steps_y + 2.62
    add_rect(s, 0.5, quote_y, 12.33, 1.0, rgb(0x1A, 0x35, 0x50))
    add_rect(s, 0.5, quote_y, 0.06, 1.0, C["gold"])
    add_text(
        s,
        "Η ασφάλεια υγείας δεν είναι κόστος — "
        "είναι επένδυση στην ηρεμία σας και στην οικογένειά σας.",
        0.7, quote_y, 12.0, 1.0, size=13, italic=True,
        color=rgb(0xC8, 0xDF, 0xF0),
    )

    _footer(s, footer_text, light=True)


# ─── PUBLIC ENTRY POINT ─────────────────────────────────────────────

def generate_pptx(
    client_name: str,
    client_members: list,
    proposals: list,
    recommended_idx: int,
    broker_name: str,
    broker_tel: str,
    broker_email: str,
    logo_bytes: bytes = None,
) -> bytes:
    """
    Build a multi-slide PPTX comparison presentation and return raw bytes.

    Slides:
        1  Cover
        2  Overview cards (all proposals side-by-side)
        3+ One detail slide per proposal
        N-1 Comparison table (all fields)
        N   Closing / call-to-action
    """
    prs = Presentation()
    prs.slide_width  = Inches(13.33)
    prs.slide_height = Inches(7.5)

    blank  = prs.slide_layouts[6]
    footer = (
        f"CHI Insurance Brokers | {broker_name}  ·  {broker_tel}  ·  {broker_email}"
    )

    _build_cover(prs, blank, client_name, client_members, proposals, footer, logo_bytes)
    _build_overview(prs, blank, client_name, proposals, recommended_idx, footer)

    for i, prop in enumerate(proposals):
        _build_proposal_slide(prs, blank, prop, i, i == recommended_idx, footer)

    _build_comparison_table(prs, blank, proposals, recommended_idx, footer)
    _build_closing(prs, blank, proposals, recommended_idx, footer)

    buf = io.BytesIO()
    prs.save(buf)
    buf.seek(0)
    return buf.read()
